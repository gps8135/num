﻿#include <stdio.h>
#include <math.h>  //sqrt 함수

// 13개의 템플릿 데이터: 각 숫자의 3x3 구역별 픽셀의 밀도
float templates[13][9] = {
    {7.90, 5.10, 7.90, 6.90, 0.00, 6.90, 7.90, 5.10, 7.90}, // 0
    {9.70, 0.00, 0.00, 9.70, 0.00, 0.00, 9.70, 0.00, 0.00}, // 1
    {7.10, 4.60, 8.40, 0.10, 4.80, 6.40, 8.10, 7.50, 4.30}, // 2
    {4.10, 9.10, 4.50, 2.70, 4.50, 8.10, 7.70, 5.80, 7.90}, // 3
    {7.40, 7.60, 8.10, 1.30, 5.00, 9.40, 6.60, 4.50, 7.50}, // 3 (두 번째 3)
    {0.40, 8.20, 5.60, 7.40, 5.00, 5.60, 4.30, 6.00, 7.70}, // 4
    {7.90, 4.80, 3.50, 6.90, 5.30, 7.70, 6.90, 5.20, 7.70}, // 5
    {1.00, 8.50, 2.50, 8.80, 4.90, 7.80, 7.80, 5.60, 7.70}, // 6
    {4.30, 5.90, 9.70, 0.00, 7.30, 3.40, 1.90, 8.20, 0.00}, // 7
    {4.30, 5.90, 9.90, 0.70, 8.90, 2.60, 8.50, 3.80, 0.00}, // 7 (두 번째 7)
    {7.10, 3.70, 7.10, 7.80, 5.10, 7.60, 6.60, 4.70, 6.50}, // 8
    {8.10, 4.00, 8.20, 4.00, 5.80, 7.10, 1.20, 8.50, 0.50}, // 9
    {8.10, 4.00, 8.20, 4.80, 4.60, 10.50, 3.20, 7.80, 4.50} // 9 (두 번째 9)
};

// 각 템플릿의 숫자와 해당 인덱스 번호를 표시하기 위한 배열
int template_labels[13] = { 0, 1, 2, 3, 3, 4, 5, 6, 7, 7, 8, 9, 9 };  //3 두개, 7 2개, 9 2개

// ANSI color codes
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"


// 상관계수 계산 함수
double calculate_correlation(double input[9], float templates[9]) {
    double sum_input = 0, sum_template = 0;
    double sum_input_sq = 0, sum_template_sq = 0;
    double sum_product = 0;
    int n = 9; //구역 갯수 1-9 (9개)

    for (int i = 0; i < n; i++) {
        sum_input += input[i];
        sum_template += templates[i];
        sum_input_sq += input[i] * input[i];
        sum_template_sq += templates[i] * templates[i];
        sum_product += input[i] * templates[i];
    }

    double numerator = sum_product - (sum_input * sum_template / n);  //분자
    double denominator = sqrt((sum_input_sq - (sum_input * sum_input / n)) * //분모
        (sum_template_sq - (sum_template * sum_template / n)));

    if (denominator == 0) return 0; // 분모가 0인 경우 상관계수는 0으로 처리

    return numerator / denominator; // 상관계수 계산
}

// 중복 숫자를 "몇 번째 x입니다" 형식으로 변환해서 출력
void print_label(int index) {
    int count = 0;
    for (int i = 0; i <= index; i++) {
        if (template_labels[i] == template_labels[index]) {
            count++;
        }
    }
    printf("%d번째 %d", count, template_labels[index]);
}

// 숫자 인식 함수: 상관계수를 모든 템플릿에 대해 출력하고, 가장 높은/두 번째로 높은/가장 낮은 템플릿을 찾음
void recognize_digit(double input[9]) {
    double correlations[13];
    double total_sum = 0.0;

    // 모든 템플릿과의 상관계수 계산 및 합산
    for (int digit = 0; digit < 13; digit++) {
        correlations[digit] = calculate_correlation(input, templates[digit]) + 1;
        total_sum += correlations[digit];
    }

    int best_match = -1, second_best_match = -1, worst_match = -1;
    double best_correlation = -1, second_best_correlation = -1, worst_correlation = 2;

    // 최적값과 최소값을 먼저 찾음
    for (int digit = 0; digit < 13; digit++) {
        double correlation = correlations[digit] - 1; // 원래 상관계수 값

        if (correlation > best_correlation) {
            second_best_correlation = best_correlation;
            second_best_match = best_match;

            best_correlation = correlation;
            best_match = digit;
        }
        else if (correlation > second_best_correlation) {
            second_best_correlation = correlation;
            second_best_match = digit;
        }

        if (correlation < worst_correlation) {
            worst_correlation = correlation;
            worst_match = digit;
        }
    }

    // 상관계수와 확률 출력: 색상 적용
    printf("모든 템플릿에 대한 상관계수 (정규화된 확률):\n");
    for (int digit = 0; digit < 13; digit++) {
        double correlation = correlations[digit] - 1; // 원래 상관계수 값
        double normalized_prob = (correlations[digit] / total_sum) * 100;

        // 색상 설정
        if (digit == best_match) {
            printf(GREEN);
        }
        else if (digit == second_best_match) {
            printf(BLUE);
        }
        else if (digit == worst_match) {
            printf(RED);
        }
        else {
            printf(YELLOW);
        }

        // 출력
        print_label(digit);
        printf(": %6.3f ( %5.2f%% )  ", correlation, normalized_prob);

        // 색상 초기화
        printf(RESET);

        if ((digit + 1) % 3 == 0) {
            printf("\n");
        }
    }
    printf("\n");

    // 최종 결과 출력: 색상 적용
    printf("가장 상관 계수가 높은 숫자: ");
    printf(GREEN);
    print_label(best_match);
    printf(GREEN " (%.3f%%)" RESET "\n", best_correlation);

    printf("두번째로 상관 계수가 높은 숫자: ");
    printf(BLUE);
    print_label(second_best_match);
    printf(BLUE " (%.3f%%)" RESET "\n", second_best_correlation);

    printf("가장 상관계수가 낮은 숫자: ");
    printf(RED);
    print_label(worst_match);
    printf(RED " (%.3f%%)" RESET "\n", worst_correlation);
}



int main() {
    // 입력 데이터 테스트
    double inputs[4][9] = {
        {3.60, 6.70, 4.30, 6.00, 5.50, 5.90, 6.20, 3.70, 8.60},  //5
        {5.70, 5.20, 7.60, 10.10, 0.00, 8.00, 8.80, 4.20, 7.80}, //0
        {4.50, 4.90, 7.10, 0.00, 4.10, 5.70, 7.20, 6.10, 2.60},  //2
        {3.60, 4.90, 7.60, 8.60, 0.00, 7.00, 7.40, 4.20, 7.70}   //0
    };

    for (int i = 0; i < 4; i++) {
        printf("%d번째 입력 데이터에 대한 결과:\n", i+1);
        recognize_digit(inputs[i]);
        printf("\n--------------------------------------\n\n");
    }

    return 0;
}
